# :boom::bomb::bomb::bomb: BOMBERs :bomb::bomb::bomb::boom:
SMS/Email/whatsapp Bombers Collection.

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) : Working </br>
![Not-Working](https://placehold.it/15/FF0000/FF0000/?text=+) : Not- Working (Or need some modifications) </br>
![Others](https://placehold.it/15/00FF00/00FF00/?text=+) : Others (pending, Some anothers issues OR not checked that is it working or not.) </br>


### SMS BOMBERS :calling: :boom:

![Not-Working](https://placehold.it/15/FF0000/FF0000/?text=+) 1. <a href="https://github.com/bhattsameer/Bombers/blob/master/SMS_bomber.py">Sms_bomber.py</a> -> sending continues sms from using one single link. 
     NOTE: Sms_bomber.py not working anymore, please refer: <a href="https://github.com/bhattsameer/Bombers/blob/master/sms_bomber_updated.py">Sms_bomber_updated.py</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 2. <a href="https://github.com/bhattsameer/Bombers/blob/master/SMS_bomber_version2.py">Sms_bomber_version2.py</a> -> sending continues sms from using one Multiple links.

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 3. <a href="https://github.com/iMro0t/bomb3r">bomb3r 💣</a> -> sending continues sms from on specified mobile number (25 different sms providers)- by <a href="https://github.com/iMro0t">iMro0t</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 4. <a href="https://github.com/bhattsameer/Bombers/blob/master/numspy_bomber.py">numspy_bomber.py</a> -> Numspy bomber sending multiple free messages using numspy module. (Currently not working need to update)

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 5. <a href="https://github.com/Bhai4You/SmS-BomB">SmS-BomB</a> -> Your Own SmS BomBer...!!! - by [Bhai4You](https://github.com/Bhai4You) 

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 6. <a href="https://github.com/KANG-NEWBIE/SpamSms">SpamSms</a> -> Spamming mobile number with OTP. - by <a href="https://github.com/KANG-NEWBIE">KANG-NEWBIE</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 7. <a href="https://github.com/KANG-NEWBIE/C-SpamMasal">C-SpamMasal</a> -> Spamming mobile number with OTP. - by <a href="https://github.com/KANG-NEWBIE">KANG-NEWBIE</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 8. <a href="https://github.com/jdleo/SMS-BOMBER">SMS-BOMBER</a> -> SMS Bomber. - by <a href="https://github.com/jdleo">jdleo</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 9. <a href="https://github.com/metachar/Tortuga">SMS spamming using email address</a> -> SMS using email. - by <a href="https://github.com/metachar/Tortuga">metachar</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 10. <a href="https://github.com/TheSpeedX/TBomb">TBomb</a> -> SMS Bomber(Ubuntu/termux) - by <a href="https://github.com/TheSpeedX">TheSpeedX</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 11. <a href="https://github.com/shellvon/smsBomb">smsBomb</a> -> SMS Bomber. - by <a href="https://github.com/shellvon">shellvon</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 12. <a href="https://github.com/aarnhub/sms-bomber">sms-bomber</a> -> SMS Bomber. - by <a href="https://github.com/aarnhub">aarnhub</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 13. <a href="https://github.com/4nat/Reborn">Reborn SMS Bomber For Termux and Linux</a> -> Reborn SMS Bomber. - by <a href="https://github.com/4nat">4nat</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 14. <a href="https://github.com/Nikait/ni_bomber">ni_bomber</a> -> SMS Bomber - by <a href="https://github.com/Nikait">Nikait</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 15. <a href="https://github.com/AvinashReddy3108/YetAnotherSMSBomber">YetAnotherSMSBomber</a> -> Sms Bomber. - by <a href="https://github.com/AvinashReddy3108">AvinashReddy3108</a>

### EMAIL BOMBERS :e-mail: :boom:

![Not-Working](https://placehold.it/15/FF0000/FF0000/?text=+) 1. <a href="https://github.com/bhattsameer/Bombers/blob/master/Email_bomber.py">Email_bomber.py</a> -> sending continues email.

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 2. <a href="https://github.com/zanyarjamal/Email-bomber">Email_bomber</a> -> sending continues email -by [zanyarjamal](https://github.com/zanyarjamal) 

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 3. <a href="https://github.com/MrMugiwara/Email-Bomb">Email_bomb</a> -> sending continues email using your yahoo and gmail account-by [MrMugiwara](https://github.com/MrMugiwara)

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 4. <a href="https://github.com/MazenElzanaty/EmBomber">EmBomber</a> -> Email Bomber. - by <a href="https://github.com/MazenElzanaty">MazenElzanaty</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 5. <a href="https://github.com/ncorbuk/Python---Email-Bomber">Python---Email-Bomber</a> -> Email Bomber. - by <a href="https://github.com/ncorbuk">ncorbuk</a>

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 6. <a href="https://github.com/Curioo/emailpyspam">EmailPySpam</a> -> Email Bomber. - by <a href="https://github.com/Curioo">Curioo</a>

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 7. <a href="https://github.com/Juniorn1003/Email-Spammer">Email-Spammer</a> -> Email Bomber. - by <a href="https://github.com/Juniorn1003">Juniorn1003</a>

### Whats-app Bombers :calling: :boom:

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 1. <a href="https://github.com/bhattsameer/Bombers/blob/master/wbomb.py">wbomb.py</a> -> Whatsapp-bomber sending multipal message to a single user

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 2. <a href="https://github.com/tbhaxor/whatabomb">whatabomb</a>  -> Whats-app bomber GUI - by [tbhaxor](https://github.com/tbhaxor)

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 3. <a href="https://github.com/bhattsameer/Bombers/blob/master/wbomb_version2.py">wbomb_version2.py (coming soon)</a> -> Whatsapp-bomber sending multipal message to multipal users.

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 4. <a href="https://github.com/rizwansoaib/WhatsApp-monitor">WhatsApp-Bomber</a>  -> WhatsApp Monitor+Bomber (Chrome Extension) - by [rizwansoaib](https://github.com/rizwansoaib)

![Others](https://placehold.it/15/00FF00/00FF00/?text=+) 5. <a href="https://github.com/macr1408/Whatsapp-scripts">WhatsApp-Spam</a> -> WhatsApp-Spam scripts - by [macr1408](https://github.com/macr1408)

### Others:

![Working](https://placehold.it/15/0000FF/0000FF/?text=+) 1. https://mailspammer.cf - Email Spammer Website. Spam piles and piles of emails! - by [WOLFIE_OG](https://github.com/WOLFIE-OG)

## Contributors:

:octocat: [iMro0t](https://github.com/iMro0t)</br> 
:octocat: [rizwansoaib](https://github.com/rizwansoaib)</br> 
:octocat: [scienceLabwork](https://github.com/scienceLabwork)</br> 

## Note:

I am not responsible for any thing you do with this script
This is just for learning and knowledge purpose.

## Please contribute!
